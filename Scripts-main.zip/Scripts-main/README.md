# redz hub
- **REDZ HUB** is just a script for automations
- the script is safe, **KEYLESS** and **FREE** for everyone. made for everyone to get the most out of it

## Working on
- 🟢Blox Fruits
- 🟢Meme sea
- 🔴Grow a Garden 2

### global load
```lua

loadstring(game:HttpGet("https://raw.githubusercontent.com/newredzv3/Scripts/refs/heads/main/main.luau"))(Settings)
```

- Blox Fruits
```lua

local Settings = {
  JoinTeam = "Pirates"; -- Pirates/Marines
  Translator = true; -- true/false
}
loadstring(game:HttpGet("https://raw.githubusercontent.com/newredzv3/Scripts/refs/heads/main/main.luau"))(Settings)
```

### This Redz Hub is a fan-made version, we welcome criticism :)  
